import torch
import torch.nn as nn


class Generator(nn.Module):
    """
    Conv1D(16) -> Conv1D(32) -> MaxPool1D(2) -> Conv1D(64)
    Flatten -> Dense(220) -> Dropout(0.01) -> Dense(220) -> Dense(1)
    """
    def __init__(self, input_channels: int, feature_size: int):
        super().__init__()

        seq_len = input_channels     # steps
        in_channels = feature_size   # n_features

        self.conv1 = nn.Conv1d(in_channels=in_channels, out_channels=16, kernel_size=3, stride=1, padding=1)
        self.conv2 = nn.Conv1d(in_channels=16, out_channels=32, kernel_size=3, stride=1, padding=1)
        self.conv3 = nn.Conv1d(in_channels=32, out_channels=64, kernel_size=3, stride=1, padding=1)
        self.pool = nn.MaxPool1d(kernel_size=2, stride=2)

        reduced_len = seq_len // 2
        fc_input_dim = reduced_len * 64

        self.flatten = nn.Flatten()
        self.fc1 = nn.Linear(fc_input_dim, 220)
        self.dropout = nn.Dropout(0.01)
        self.fc2 = nn.Linear(220, 220)
        self.fc3 = nn.Linear(220, 1)

        self.relu = nn.ReLU()

    def forward(self, inputs: torch.Tensor):
        # inputs: (B, steps, n_features) -> (B, n_features, steps)
        x = inputs.permute(0, 2, 1)
        x = self.relu(self.conv1(x))
        x = self.relu(self.conv2(x))
        x = self.pool(x)
        x = self.relu(self.conv3(x))

        x = self.flatten(x)
        x = self.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.relu(self.fc2(x))
        output = self.fc3(x)
        return output
